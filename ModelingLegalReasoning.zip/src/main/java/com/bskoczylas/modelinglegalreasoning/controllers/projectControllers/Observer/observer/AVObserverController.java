package com.bskoczylas.modelinglegalreasoning.controllers.projectControllers.Observer.observer;

import com.bskoczylas.modelinglegalreasoning.controllers.projectControllers.AVController;

public interface AVObserverController {
    void updateAV(AVController avController);
}
