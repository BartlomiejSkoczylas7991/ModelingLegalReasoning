package com.bskoczylas.modelinglegalreasoning.controllers.projectControllers.Observer.observer;

import com.bskoczylas.modelinglegalreasoning.controllers.projectControllers.ValueController;

public interface ValueControllerObserver {
    void updateValueController(ValueController valueController);
}
