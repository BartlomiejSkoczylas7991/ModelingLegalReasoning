package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.consortium;

public enum ConsortiumType {
    MAJORITY,
    PLURALITY,
    CONCURRING,
    DISSENTING
}
