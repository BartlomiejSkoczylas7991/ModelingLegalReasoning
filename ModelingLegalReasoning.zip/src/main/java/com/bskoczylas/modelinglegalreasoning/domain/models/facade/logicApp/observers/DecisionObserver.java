package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.observers;

import com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.decision.Decision;

public interface DecisionObserver {
    public void update(Decision decision);
}
