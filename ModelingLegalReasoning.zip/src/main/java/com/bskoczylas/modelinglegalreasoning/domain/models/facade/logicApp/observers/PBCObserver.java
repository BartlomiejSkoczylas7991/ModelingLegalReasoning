package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.observers;

import com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.propBaseClean.ListPropBaseClean;

public interface PBCObserver {
    void updatePBC(ListPropBaseClean propBaseClean);
}
