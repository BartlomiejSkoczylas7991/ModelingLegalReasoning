package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.proposition;

import org.junit.jupiter.api.Test;

class ListPropositionTest {

    @Test
    void getPropositions() {
    }

    @Test
    void addProposition() {
    }

    @Test
    void removeProposition() {
    }

    @Test
    void setListProposition() {
    }

    @Test
    void addObserver() {
    }

    @Test
    void removeObserver() {
    }

    @Test
    void notifyObservers() {
    }
}