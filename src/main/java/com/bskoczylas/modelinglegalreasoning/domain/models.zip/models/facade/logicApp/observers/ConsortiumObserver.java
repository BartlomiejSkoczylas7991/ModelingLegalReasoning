package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.observers;

import com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.consortium.ListConsortium;

public interface ConsortiumObserver {
    public void updateCon(ListConsortium listConsortium);
}
