package com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.observers;
import com.bskoczylas.modelinglegalreasoning.domain.models.facade.logicApp.weights.scale_Weight.Scale;

public interface ScaleObserver {
    void updateScale(Scale scale);
}
