package com.bskoczylas.modelinglegalreasoning.domain.models.projectObserver;

import com.bskoczylas.modelinglegalreasoning.domain.models.Project;
public interface ProjectObserver {
    void updateProject( Project project);
}
